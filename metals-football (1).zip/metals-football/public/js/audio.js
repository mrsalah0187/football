/* مؤثرات صوتية مولَّدة برمجيًا (WebAudio) — بدون ملفات خارجية */
(function (root) {
  'use strict';
  let ctx = null, master = null, crowdGain = null, crowdOn = false, muted = false, noiseBuf = null;

  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = root.AudioContext || root.webkitAudioContext; if (!AC) return;
    ctx = new AC(); master = ctx.createGain(); master.gain.value = muted ? 0 : 0.8; master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  function noise(dur, type, f0, f1, gain, when) {
    if (!ctx) return; const t = ctx.currentTime + (when || 0);
    const s = ctx.createBufferSource(); s.buffer = noiseBuf; const f = ctx.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(master); s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }
  function tone(freq, dur, type, gain, when, f1) {
    if (!ctx) return; const t = ctx.currentTime + (when || 0), o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(gain, t + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }
  function whistle(n) {
    if (!ctx) return;
    for (let i = 0; i < (n || 1); i++) {
      const t = i * 0.28, o = ctx.createOscillator(), lfo = ctx.createOscillator(), lg = ctx.createGain(), g = ctx.createGain(), st = ctx.currentTime + t;
      o.type = 'square'; o.frequency.value = 2900; lfo.frequency.value = 38; lg.gain.value = 120; lfo.connect(lg); lg.connect(o.frequency);
      g.gain.setValueAtTime(0.0001, st); g.gain.exponentialRampToValueAtTime(0.16, st + 0.02); g.gain.setValueAtTime(0.16, st + 0.2); g.gain.exponentialRampToValueAtTime(0.0001, st + 0.26);
      o.connect(g); g.connect(master); o.start(st); lfo.start(st); o.stop(st + 0.3); lfo.stop(st + 0.3);
    }
  }
  function crowd(on) {
    if (!ctx) return;
    if (on && !crowdOn) {
      crowdOn = true; const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 700; f.Q.value = 0.5;
      crowdGain = ctx.createGain(); crowdGain.gain.value = 0.05; s.connect(f); f.connect(crowdGain); crowdGain.connect(master); s.start(); crowd._src = s;
    } else if (!on && crowdOn) { crowdOn = false; try { crowd._src.stop(); } catch (e) { /* */ } }
  }
  function swell(peak, secs) {
    if (!crowdGain) return; const t = ctx.currentTime;
    crowdGain.gain.cancelScheduledValues(t); crowdGain.gain.setValueAtTime(crowdGain.gain.value, t);
    crowdGain.gain.linearRampToValueAtTime(peak, t + 0.4); crowdGain.gain.linearRampToValueAtTime(0.05, t + secs);
  }

  const FX = {
    whistle: () => whistle(1), kick: () => { noise(0.09, 'lowpass', 900, 120, 0.5); tone(120, 0.08, 'sine', 0.35, 0, 60); },
    tackle: () => noise(0.18, 'bandpass', 500, 200, 0.25), shot: () => { noise(0.12, 'lowpass', 1600, 150, 0.7); tone(90, 0.14, 'sine', 0.5, 0, 45); swell(0.16, 2.2); },
    save: () => { noise(0.12, 'bandpass', 1200, 400, 0.45); swell(0.14, 1.6); }, out: () => {}, miss: () => { swell(0.12, 1.2); },
    question: () => { tone(660, 0.12, 'triangle', 0.18); tone(880, 0.16, 'triangle', 0.18, 0.12); },
    correct: () => { tone(523, 0.12, 'triangle', 0.22); tone(659, 0.12, 'triangle', 0.22, 0.1); tone(784, 0.22, 'triangle', 0.22, 0.2); },
    wrong: () => { tone(220, 0.22, 'sawtooth', 0.16, 0, 140); tone(150, 0.3, 'sawtooth', 0.14, 0.18, 90); },
    goal: () => { whistle(2); swell(0.55, 6); [0, 0.15, 0.3].forEach((d, i) => tone([392, 523, 659][i], 0.5, 'triangle', 0.18, 0.2 + d)); for (let i = 0; i < 6; i++) noise(0.6, 'bandpass', 800 + i * 150, 400, 0.12, 0.1 + i * 0.1); },
    tick: () => tone(1000, 0.05, 'square', 0.07), beep: () => tone(880, 0.12, 'sine', 0.2), click: () => tone(600, 0.04, 'square', 0.06)
  };
  function play(n) { if (!ctx || muted) return; const f = FX[n]; if (f) { try { f(); } catch (e) { /* */ } } }
  function setMuted(v) { muted = !!v; if (master) master.gain.value = muted ? 0 : 0.8; }

  root.Sound = { init, play, crowd, setMuted, isMuted: () => muted };
})(window);
