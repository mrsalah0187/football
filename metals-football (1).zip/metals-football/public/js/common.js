/* أدوات مشتركة بين صفحة الطالب وصفحة المعلم */
(function (root) {
  'use strict';
  const TEAMS = ['الفريق الأحمر', 'الفريق الأزرق'];
  const $ = (id) => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = s => { s = Math.max(0, Math.floor(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

  // ---------- اتصال WebSocket مع إعادة اتصال تلقائية ----------
  function connect(handlers) {
    const proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
    const url = proto + location.host + '/ws';
    const c = { ws: null, open: false, closed: false, tries: 0 };
    function go() {
      const ws = new WebSocket(url); c.ws = ws;
      ws.onopen = () => { c.open = true; c.tries = 0; handlers.open && handlers.open(); };
      ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } handlers.msg && handlers.msg(m); };
      ws.onclose = () => { c.open = false; handlers.close && handlers.close(); if (!c.closed) setTimeout(go, Math.min(4000, 500 + c.tries++ * 600)); };
      ws.onerror = () => { try { ws.close(); } catch (x) { /* */ } };
    }
    c.send = o => { if (c.ws && c.ws.readyState === 1) c.ws.send(JSON.stringify(o)); };
    c.close = () => { c.closed = true; try { c.ws.close(); } catch (e) { /* */ } };
    go(); return c;
  }

  // ---------- بطاقة العنصر ----------
  function elementCardHTML(id) {
    const e = MData.ELEMENTS[id]; if (!e) return '';
    const cell = MData.CELLS.find(c => c.sym === id), col = MData.CAT_COLOR[cell ? cell.cat : 'transition'];
    const ul = a => '<ul>' + a.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>';
    return `<div class="elcard" dir="rtl"><div class="elhead" style="--ec:${col}">
      <div class="elsym"><span class="z">${e.z}</span><span class="s">${e.sym}</span><span class="m">${e.mass}</span></div>
      <div><h2 class="elname">${esc(e.ar)}</h2><div class="elen">${esc(e.en)}</div>
      <div style="margin-top:6px"><span class="pill">الرمز: ${e.sym}</span> <span class="pill">العدد الذري: ${e.z}</span> <span class="pill">الكتلة الذرية: ${e.mass}</span></div></div></div>
      <div class="elbody">
        <div class="elbox"><h4>🔬 الخواص الفيزيائية</h4>${ul(e.physical)}</div>
        <div class="elbox"><h4>⚗️ الخواص الكيميائية</h4>${ul(e.chemical)}</div>
        <div class="elbox"><h4>🛠️ الاستخدامات</h4>${ul(e.uses)}</div>
        <div class="elbox fact"><h4>💡 هل تعلم؟</h4><div style="font-size:14.5px;line-height:1.7">${esc(e.fact)}</div></div>
      </div></div>`;
  }

  // ---------- شاشة النهاية ----------
  function endHTML(res) {
    if (!res) return '';
    const w = res.winner, tn = TEAMS;
    const title = w === -1 ? 'تعادل! 🤝' : '🏆 الفائز: ' + tn[w];
    const colors = ['var(--t0)', 'var(--t1)'];
    const aw = (ic, ttl, nm, sub) => `<div class="award"><div class="ic">${ic}</div><div class="ttl">${ttl}</div><div class="nm">${nm ? esc(nm) : '—'}</div><div class="mut" style="font-size:12px">${sub || ''}</div></div>`;
    const rows = res.rows.map((r, i) => `<tr><td>${i + 1}</td><td><span class="dot t${r.team}"></span>${esc(r.name)}</td><td>${r.goals}</td><td>${r.correct}</td><td>${r.wrong}</td><td>${r.tackles}</td><td>${r.saves}</td><td><b>${r.rating}</b></td></tr>`).join('');
    const T = res.teams;
    const cmp = (lbl, a, b, suffix) => { const s = (a + b) || 1; return `<div>${a}${suffix || ''}</div><div><div class="lbl">${lbl}</div><div class="bar" style="width:160px"><i style="width:${a / s * 100}%;background:var(--t0);float:left"></i><i style="width:${b / s * 100}%;background:var(--t1);float:right"></i></div></div><div>${b}${suffix || ''}</div>`; };
    return `<div class="endwrap">
      <div class="winner">${title}</div>
      <div class="finalscore"><span class="n" style="background:${colors[0]}">${tn[0]}</span><span>${res.score[0]}</span><span>-</span><span>${res.score[1]}</span><span class="n" style="background:${colors[1]}">${tn[1]}</span></div>
      <div class="awards">
        ${aw('⭐', 'أفضل لاعب', res.mvp && res.mvp.name, res.mvp ? 'تقييم ' + res.mvp.rating : '')}
        ${aw('🧠', 'أكثر إجابات صحيحة', res.topAnswerer && res.topAnswerer.name, res.topAnswerer ? res.topAnswerer.correct + ' إجابة صحيحة' : '')}
        ${aw('⚽', 'أفضل هداف', res.topScorer && res.topScorer.name, res.topScorer ? res.topScorer.goals + ' هدف' : '')}
      </div>
      <div class="card"><div class="cmp">${cmp('التسديدات', T[0].shots, T[1].shots)}${cmp('الأسئلة الصحيحة', T[0].correct, T[1].correct)}${cmp('الأسئلة الخاطئة', T[0].wrong, T[1].wrong)}${cmp('التصديات', T[0].saves, T[1].saves)}${cmp('الاستحواذ', T[0].poss, T[1].poss, '%')}</div></div>
      <div class="card" style="overflow:auto"><table class="tb"><thead><tr><th>#</th><th>الطالب</th><th>أهداف</th><th>صحيحة</th><th>خاطئة</th><th>تدخلات</th><th>تصديات</th><th>التقييم</th></tr></thead><tbody>${rows || '<tr><td colspan="8" class="mut">لا توجد بيانات</td></tr>'}</tbody></table></div>
    </div>`;
  }

  // ---------- عرض المباراة (استيفاء + أحداث) ----------
  class GameView {
    constructor(cv, opts) {
      this.field = new Render.Field3D(cv); this.field.flip = !!opts.flip;
      this.meId = opts.meId === undefined ? -1 : opts.meId; this.names = {};
      this.buf = []; this.last = null; this.onEvent = opts.onEvent || (() => {}); this.running = true;
      this.tPrev = performance.now(); this.radar = opts.radar || null; this.delay = 110;
      addEventListener('resize', () => this.field.resize());
      const loop = (t) => { if (!this.running) return; const dt = Math.min(0.1, (t - this.tPrev) / 1000); this.tPrev = t; this.frame(dt); requestAnimationFrame(loop); };
      requestAnimationFrame(loop);
    }
    feed(s) {
      const now = performance.now(); this.last = s;
      this.buf.push({ t: now, s }); if (this.buf.length > 8) this.buf.shift();
      if (s.ev) s.ev.forEach(e => { if (e[0] === 'goal') this.field.burst(e[1]); this.onEvent(e[0], e[1]); });
    }
    state() {
      const b = this.buf; if (!b.length) return null;
      const T = performance.now() - this.delay; let i = b.length - 1;
      if (T >= b[i].t || b.length === 1) return { players: b[i].s.p, ball: b[i].s.b };
      while (i > 0 && b[i - 1].t > T) i--;
      if (i === 0) return { players: b[0].s.p, ball: b[0].s.b };
      const A = b[i - 1], B = b[i], k = Math.min(1, Math.max(0, (T - A.t) / Math.max(1, B.t - A.t)));
      const players = B.s.p.map((q, j) => {
        const p = A.s.p[j]; if (Math.hypot(q[0] - p[0], q[1] - p[1]) > 12) return q;
        let df = q[2] - p[2]; while (df > Math.PI) df -= 2 * Math.PI; while (df < -Math.PI) df += 2 * Math.PI;
        return [p[0] + (q[0] - p[0]) * k, p[1] + (q[1] - p[1]) * k, p[2] + df * k, q[3], q[4]];
      });
      const pb = A.s.b, qb = B.s.b, jump = Math.hypot(qb[0] - pb[0], qb[1] - pb[1]) > 15;
      const ball = jump ? qb : [pb[0] + (qb[0] - pb[0]) * k, pb[1] + (qb[1] - pb[1]) * k, pb[2] + (qb[2] - pb[2]) * k, qb[3], qb[4]];
      return { players, ball };
    }
    frame(dt) {
      const st = this.state(); if (!st) { this.field.render({ players: [], ball: [0, 0, 0, -1, 0], meId: -1 }, dt); return; }
      const ball = st.ball;
      this.field.follow(ball[0], ball[1], dt);
      this.field.render({ players: st.players, ball, meId: this.meId, names: this.names }, dt);
      if (this.radar) Render.drawRadar(this.radar, st.players, ball, this.field.flip, this.meId);
    }
    stop() { this.running = false; }
  }

  root.Common = { TEAMS, $, esc, fmt, connect, elementCardHTML, endHTML, GameView };
})(window);
