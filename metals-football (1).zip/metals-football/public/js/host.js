/* لوحة المعلم: إنشاء المباراة، التحكم، مشاهدة البث المباشر، النتائج */
(function () {
  'use strict';
  const { $, esc, fmt, TEAMS } = Common;
  const SAVE = 'mfc_host';
  const H = { room: null, pin: null, token: null, view: null, shown: null, last: null, cfg: {} };
  const load = () => { try { return JSON.parse(localStorage.getItem(SAVE) || 'null'); } catch (e) { return null; } };
  const save = o => { try { localStorage.setItem(SAVE, JSON.stringify(o)); } catch (e) { /* */ } };

  fetch('/api/config').then(r => r.json()).then(c => { H.cfg = c; if (c.hostPasswordRequired) $('hPwd').classList.remove('hidden'); }).catch(() => { });
  function paintBg() { const c = $('bg-host'); if (c && c.offsetWidth) { Render.drawLineup(c, null); const g = c.getContext('2d'); g.fillStyle = 'rgba(4,10,24,.72)'; g.fillRect(0, 0, c.offsetWidth, c.offsetHeight); } }
  setTimeout(paintBg, 50); addEventListener('resize', paintBg);

  const conn = Common.connect({
    open() { $('conn').classList.add('hidden'); const s = load(); if (s && (!H.pin || H.pin === s.pin)) conn.send({ t: 'host_resume', pin: s.pin, token: s.token }); },
    close() { $('conn').classList.remove('hidden'); },
    msg(m) {
      if (m.t === 'host_ok') { H.pin = m.pin; H.token = m.token; save({ pin: m.pin, token: m.token }); enterPanel(); }
      else if (m.t === 'room') { H.room = m; renderRoom(); }
      else if (m.t === 's') onSnap(m);
      else if (m.t === 'err') { if (m.code === 'no_room') { try { localStorage.removeItem(SAVE); } catch (e) { /* */ } $('h-login').classList.remove('hidden'); $('h-panel').classList.add('hidden'); } $('hErr').textContent = m.msg; alert(m.code === 'no_room' ? 'انتهت صلاحية المباراة السابقة. أنشئ مباراة جديدة.' : m.msg); }
    }
  });
  $('btnCreate').onclick = () => { Sound.init(); $('hErr').textContent = ''; conn.send({ t: 'host_create', pwd: $('hPwd').value }); };

  function enterPanel() {
    $('h-login').classList.add('hidden'); $('h-panel').classList.remove('hidden');
    $('hPin').textContent = H.pin; const setLink = base => { $('hLink').value = base + '/?pin=' + H.pin; };
    setLink(location.origin);
    if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) fetch('/api/lan').then(r => r.json()).then(c => { if (c.ips && c.ips.length) setLink('http://' + c.ips[0] + ':' + (location.port || c.port)); }).catch(() => { });
    if (!H.view) { H.view = new Common.GameView($('field'), { flip: false, meId: -1, onEvent: onEvent }); }
    H.view.field.resize();
  }
  $('btnCopy').onclick = () => { const i = $('hLink'); i.select(); try { navigator.clipboard.writeText(i.value); } catch (e) { document.execCommand('copy'); } $('btnCopy').textContent = 'تم ✓'; setTimeout(() => $('btnCopy').textContent = 'نسخ', 1500); };

  const cmd = (c, v) => conn.send({ t: 'host_cmd', cmd: c, value: v });
  $('btnStart').onclick = () => { Sound.init(); cmd('duration', +$('selDur').value); cmd('start'); };
  $('btnPause').onclick = () => cmd('pause');
  $('btnResume').onclick = () => cmd('resume');
  $('btnEnd').onclick = () => { if (confirm('إنهاء المباراة الآن وعرض النتائج؟')) cmd('end'); };
  $('btnRestart').onclick = () => { if (confirm('إعادة المباراة من البداية؟ ستُصفَّر النتيجة والوقت.')) { cmd('duration', +$('selDur').value); cmd('restart'); } };
  $('btnLobby').onclick = () => cmd('back_to_lobby');
  $('selDur').onchange = () => cmd('duration', +$('selDur').value);
  $('btnMute').onclick = () => { Sound.setMuted(!Sound.isMuted()); $('btnMute').textContent = Sound.isMuted() ? '🔇' : '🔊'; };
  $('btnFs').onclick = () => { const s = $('stage'); s.classList.toggle('full'); setTimeout(() => { H.view && H.view.field.resize(); }, 50); };
  addEventListener('keydown', e => { if (e.key === 'Escape') { $('stage').classList.remove('full'); H.view && H.view.field.resize(); } });
  addEventListener('resize', () => { if (H.room && H.room.status === 'lobby') Render.drawLineup($('lineupCv'), H.room.lineup); });

  function onEvent(e) { Sound.play(e); if (e === 'goal') Sound.play('goal'); }
  function toast(t, ms) { const el = $('toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove('on'), ms || 1800); }

  const STATUS = { lobby: 'غرفة الانتظار — لم تبدأ المباراة', countdown: 'العدّ التنازلي…', playing: 'المباراة جارية 🟢', question: 'سؤال علمي ❓', qresult: 'نتيجة السؤال', goal: 'هدف! ⚽', paused: 'متوقفة مؤقتًا ⏸', finished: 'انتهت المباراة 🏁' };
  function renderRoom() {
    const r = H.room, st = r.status; if (!H.pin) return;
    $('hCount').textContent = r.students.length; $('hc0').textContent = r.counts[0]; $('hc1').textContent = r.counts[1];
    $('hList').innerHTML = r.students.length ? r.students.map(s => `<div class="srow"><span class="on ${s.online ? 'y' : ''}"></span>${esc(s.name)}<span class="tn ${s.team === null ? 'tx' : 't' + s.team}">${s.team === null ? 'بلا فريق' : TEAMS[s.team]}</span><button title="إخراج" data-k="${s.id}">✕</button></div>`).join('') : '<div class="mut">لم ينضم أحد بعد…</div>';
    $('hList').querySelectorAll('button[data-k]').forEach(b => b.onclick = () => { if (confirm('إخراج هذا الطالب؟')) conn.send({ t: 'host_cmd', cmd: 'kick', sid: b.dataset.k }); });
    $('hStatus').textContent = STATUS[st] || st; $('hsA').textContent = r.score[0]; $('hsB').textContent = r.score[1];
    if (st === 'lobby' || st === 'finished') $('selDur').value = String(r.duration / 60);
    const playing = ['countdown', 'playing', 'question', 'qresult', 'goal'].includes(st);
    $('btnStart').disabled = st !== 'lobby' || r.students.length === 0;
    $('btnPause').disabled = !playing; $('btnResume').disabled = st !== 'paused'; $('btnEnd').disabled = !(playing || st === 'paused');
    $('btnRestart').disabled = st === 'lobby'; $('btnLobby').disabled = st !== 'finished'; $('selDur').disabled = !(st === 'lobby' || st === 'finished');
    // ما يُعرض في المسرح
    const lobby = st === 'lobby';
    $('lineupCv').classList.toggle('hidden', !lobby); $('field').classList.toggle('hidden', lobby);
    $('scoreboard').classList.toggle('hidden', lobby); $('stage').classList.toggle('hidden', st === 'finished' && !!H.last && !!H.last.res && false);
    if (lobby) Render.drawLineup($('lineupCv'), r.lineup);
    if (!lobby && H.view) H.view.names = r.names || {};
    if (st !== 'finished') $('endArea').classList.add('hidden');
    if (st === 'finished' && H.last && H.last.res) { $('endArea').innerHTML = Common.endHTML(H.last.res); $('endArea').classList.remove('hidden'); }
  }

  function onSnap(s) {
    H.last = s; if (!H.view || !H.room) return;
    if (s.st === 'finished' && s.res && $('endArea').classList.contains('hidden')) { $('endArea').innerHTML = Common.endHTML(s.res); $('endArea').classList.remove('hidden'); }
    H.view.feed(s); Sound.crowd(s.st === 'playing' || s.st === 'goal');
    $('scA').textContent = s.sc[0]; $('scB').textContent = s.sc[1]; $('clk').textContent = fmt(s.dur - s.clk);
    $('hsA').textContent = s.sc[0]; $('hsB').textContent = s.sc[1]; $('hStatus').textContent = STATUS[s.st] || s.st;
    $('half').textContent = s.st === 'paused' ? 'PAUSED' : (s.st === 'question' || s.st === 'qresult') ? '❓ سؤال' : 'LIVE';
    const b = $('banner');
    if (s.st === 'goal' && s.goal) { const k = 'g' + s.sc.join('-'); if (H.shown !== k) { H.shown = k; b.innerHTML = '<div class="big">GOAL!</div><div class="sub">⚽ ' + esc(s.goal.scorer) + ' — ' + TEAMS[s.goal.team] + '</div>'; } }
    else if (s.st === 'countdown') { const k = 'c' + s.cd; if (H.shown !== k) { H.shown = k; b.innerHTML = '<div id="cdown">' + s.cd + '</div>'; Sound.play('tick'); } }
    else if (H.shown) { H.shown = null; b.innerHTML = ''; }
    const ov = $('status-ov'); ov.classList.toggle('hidden', s.st !== 'paused'); if (s.st === 'paused') ov.textContent = '⏸ المباراة متوقفة مؤقتًا';
    // عرض السؤال للمعلم (للقراءة فقط)
    const qr = $('qread'), q = s.q;
    if (q && (s.st === 'question' || s.st === 'qresult')) {
      const L = ['أ', 'ب', 'ج', 'د'];
      qr.innerHTML = `<div style="display:flex;justify-content:space-between;font-size:13px;color:var(--gold);font-weight:800"><span>❓ سؤال لـ ${TEAMS[q.team]}</span><span>⏱ ${Math.ceil(q.left)} ث</span></div><div class="qtimer" style="margin:6px 0"><i style="width:${q.left / q.total * 100}%"></i></div><div class="t">${esc(q.text)}</div><div class="o">${q.opts.map((o, i) => `<div class="${q.res ? (i === q.res.right ? 'right' : i === q.res.choice ? 'wrong' : '') : ''}">${L[i]}) ${esc(o)}</div>`).join('')}</div>`;
      qr.classList.remove('hidden');
    } else qr.classList.add('hidden');
  }
  window.__H = H;
})();
