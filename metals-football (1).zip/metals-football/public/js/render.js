/* عارض ملعب كرة القدم بمنظور ثلاثي الأبعاد حقيقي (إسقاط كاميرا + قص المستوى القريب) على Canvas 2D
   بدون أي مكتبات خارجية. يُستخدم في صفحة الطالب وصفحة المعلم. */
(function (root) {
  'use strict';
  const HX = 52.5, HY = 34, GH = 2.44, GW = 3.66, BOX_X = 16.5, BOX_Y = 20.16;
  const KIT = [
    { shirt: '#d62839', shorts: '#f4f4f4', socks: '#d62839', gk: '#ffd23f', gkShorts: '#161616' },
    { shirt: '#1f6fe5', shorts: '#0b2a63', socks: '#1f6fe5', gk: '#3ddc97', gkShorts: '#161616' }
  ];
  const TEAM_NAMES = ['فريق الحديد', 'فريق الفضة'];
  const SKIN = ['#f1c27d', '#e0ac69', '#c68642', '#8d5524', '#ffdbac', '#d9a066'];
  const HAIR = ['#1b1b1b', '#3b2417', '#0e0e0e', '#5a3a22'];
  const ROLE_NUM = [1, 3, 4, 5, 2, 11, 8, 6, 7, 9, 10];
  const BOARD = [['Fe', '#c0392b'], ['Cu', '#d2691e'], ['Al', '#5d6d7e'], ['Au', '#b8860b'], ['Ag', '#7f8c8d'], ['Na', '#e67e22'], ['K', '#8e44ad'], ['Mg', '#16a085'], ['Ca', '#c0392b'], ['Zn', '#2980b9'], ['Li', '#c2185b'], ['Sn', '#34495e']];
  const NEAR = 0.8;

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function clipNear(poly) {
    const out = [];
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length], ain = a[2] >= NEAR, bin = b[2] >= NEAR;
      if (ain) out.push(a);
      if (ain !== bin) { const t = (NEAR - a[2]) / (b[2] - a[2]); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR]); }
    }
    return out;
  }
  function rngMaker(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

  class Field3D {
    constructor(canvas) {
      this.cv = canvas; this.g = canvas.getContext('2d');
      this.flip = false; this.cam = { x: 0, y: 0 }; this.shake = 0; this.exc = 0.2; this.parts = []; this.anim = {};
      this.t = 0; this.ballTrail = [];
      this._seed(); this.resize();
    }
    _seed() {
      const r = rngMaker(7), cols = ['#e63946', '#f1faee', '#457b9d', '#ffd166', '#1d3557', '#a8dadc', '#f4a261', '#2a9d8f', '#e9ecef'];
      this.crowd = [];
      const add = (side, n, pal) => { for (let i = 0; i < n; i++) this.crowd.push({ side, u: r(), v: r(), c: pal[Math.floor(r() * pal.length)], ph: r() * 6.28 }); };
      add('far', 1500, cols); add('left', 450, ['#e63946', '#f1faee', '#c1121f', '#ffd166']); add('right', 450, ['#1f6fe5', '#f1faee', '#a8dadc', '#1d3557']);
    }
    resize() {
      const r = this.cv.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.W = Math.max(2, r.width); this.H = Math.max(2, r.height); this.dpr = dpr;
      this.cv.width = Math.round(this.W * dpr); this.cv.height = Math.round(this.H * dpr);
      this.f = Math.min(this.W / 1.28, this.H * 1.35);
    }
    follow(wx, wy, dt) {
      const tx = this.flip ? -wx : wx, ty = this.flip ? -wy : wy;
      const k = Math.min(1, 4.5 * dt);
      this.cam.x += (clamp(tx, -44, 44) - this.cam.x) * k;
      this.cam.y += (clamp(ty, -17, 17) - this.cam.y) * k;
    }
    burst(team) {
      const cols = team === 0 ? ['#ff4d5e', '#ffffff', '#ffd23f'] : ['#4d8dff', '#ffffff', '#ffd23f'];
      for (let i = 0; i < 180; i++) this.parts.push({ x: Math.random() * this.W, y: -20 - Math.random() * this.H * 0.5, vx: (Math.random() - 0.5) * 120, vy: 60 + Math.random() * 220, r: Math.random() * 6, vr: (Math.random() - 0.5) * 12, c: cols[i % 3], w: 5 + Math.random() * 6, h: 3 + Math.random() * 5, life: 4 + Math.random() * 2 });
      this.shake = 1; this.exc = 1.2;
    }
    // ---------- كاميرا ----------
    _prep() {
      const sh = this.shake * 0.35;
      this.ex = this.cam.x + (Math.random() - 0.5) * sh; this.ey = this.cam.y - 40 + (Math.random() - 0.5) * sh; this.ez = 34 + (Math.random() - 0.5) * sh * 0.5;
      const L = Math.hypot(40, this.ez);
      this.fy = 40 / L; this.fz = -this.ez / L; this.uy = this.ez / L; this.uz = 40 / L;
    }
    _cs(p) { const vx = p[0] - this.ex, vy = p[1] - this.ey, vz = p[2] - this.ez; return [vx, vy * this.uy + vz * this.uz, vy * this.fy + vz * this.fz]; }
    _pr(c) { const k = this.f / c[2]; return [this.W / 2 + c[0] * k, this.H * 0.52 - c[1] * k]; }
    _fl(x, y, z) { return this.flip ? [-x, -y, z] : [x, y, z]; }
    P(x, y, z) {
      const c = this._cs(this._fl(x, y, z)); if (c[2] < NEAR) return null;
      const k = this.f / c[2]; return { x: this.W / 2 + c[0] * k, y: this.H * 0.52 - c[1] * k, d: c[2], k };
    }
    poly(pts, color, stroke) {
      let cs = clipNear(pts.map(p => this._cs(this._fl(p[0], p[1], p[2])))); if (cs.length < 3) return;
      const g = this.g; g.beginPath();
      cs.forEach((c, i) => { const s = this._pr(c); if (i) g.lineTo(s[0], s[1]); else g.moveTo(s[0], s[1]); });
      g.closePath(); if (color) { g.fillStyle = color; g.fill(); } if (stroke) { g.strokeStyle = stroke; g.lineWidth = 1; g.stroke(); }
    }
    gline(x1, y1, x2, y2, w, color) {
      const dx = x2 - x1, dy = y2 - y1, l = Math.hypot(dx, dy) || 1, nx = -dy / l * w / 2, ny = dx / l * w / 2;
      this.poly([[x1 + nx, y1 + ny, 0.01], [x2 + nx, y2 + ny, 0.01], [x2 - nx, y2 - ny, 0.01], [x1 - nx, y1 - ny, 0.01]], color);
    }
    seg(a, b, lw, color) {
      let c1 = this._cs(this._fl(a[0], a[1], a[2])), c2 = this._cs(this._fl(b[0], b[1], b[2]));
      if (c1[2] < NEAR && c2[2] < NEAR) return;
      if (c1[2] < NEAR) { const t = (NEAR - c1[2]) / (c2[2] - c1[2]); c1 = [c1[0] + (c2[0] - c1[0]) * t, c1[1] + (c2[1] - c1[1]) * t, NEAR]; }
      if (c2[2] < NEAR) { const t = (NEAR - c2[2]) / (c1[2] - c2[2]); c2 = [c2[0] + (c1[0] - c2[0]) * t, c2[1] + (c1[1] - c2[1]) * t, NEAR]; }
      const s1 = this._pr(c1), s2 = this._pr(c2), g = this.g;
      g.beginPath(); g.moveTo(s1[0], s1[1]); g.lineTo(s2[0], s2[1]); g.strokeStyle = color; g.lineWidth = lw; g.lineCap = 'round'; g.stroke();
    }
    // ---------- المشهد ----------
    drawScene() {
      const g = this.g, W = this.W, H = this.H;
      // سماء الملعب الليلية
      const sky = g.createLinearGradient(0, 0, 0, H * 0.55); sky.addColorStop(0, '#050b1c'); sky.addColorStop(1, '#16315c');
      g.fillStyle = sky; g.fillRect(0, 0, W, H);
      this._stands(); this._boards(); this._pitch(); this._goal(-1); this._goal(1); this._flags();
    }
    _standPt(side, u, v) {
      if (side === 'far') return [(u - 0.5) * (2 * HX + 30), HY + 5 + 19 * v, 0.8 + 12 * v];
      const s = side === 'left' ? -1 : 1; return [s * (HX + 6 + 19 * v), (u - 0.5) * (2 * HY + 10), 0.8 + 12 * v];
    }
    _stands() {
      const tiers = ['#1a2744', '#16213a'];
      [['far'], ['left'], ['right']].forEach(([side]) => {
        const c = [this._standPt(side, 0, 0), this._standPt(side, 1, 0), this._standPt(side, 1, 1), this._standPt(side, 0, 1)];
        this.poly(c, '#141d33');
        for (let i = 0; i < 8; i++) { const v0 = i / 8, v1 = (i + 0.55) / 8; this.poly([this._standPt(side, 0, v0), this._standPt(side, 1, v0), this._standPt(side, 1, v1), this._standPt(side, 0, v1)], tiers[i % 2]); }
      });
      const t = this.t, exc = this.exc;
      for (const d of this.crowd) {
        const p3 = this._standPt(d.side, d.u, d.v);
        const bob = (0.05 + exc * 0.5) * Math.abs(Math.sin(t * (3 + exc * 5) + d.ph));
        const s = this.P(p3[0], p3[1], p3[2] + 0.55 + bob); if (!s) continue;
        const r = Math.max(1.1, 0.34 * s.k); if (s.x < -r || s.x > this.W + r || s.y < -r || s.y > this.H + r) continue;
        this.g.fillStyle = d.c; this.g.fillRect(s.x - r, s.y - r, r * 2, r * 2.2);
      }
      // توهج كشافات
      const g = this.g, gl = g.createRadialGradient(this.W * 0.15, 0, 10, this.W * 0.15, 0, this.W * 0.5); gl.addColorStop(0, 'rgba(255,255,235,.35)'); gl.addColorStop(1, 'rgba(255,255,235,0)');
      g.fillStyle = gl; g.fillRect(0, 0, this.W, this.H);
      const gl2 = g.createRadialGradient(this.W * 0.85, 0, 10, this.W * 0.85, 0, this.W * 0.5); gl2.addColorStop(0, 'rgba(255,255,235,.3)'); gl2.addColorStop(1, 'rgba(255,255,235,0)');
      g.fillStyle = gl2; g.fillRect(0, 0, this.W, this.H);
    }
    _boards() {
      const g = this.g, y = HY + 2.4, n = 14, w = (2 * HX + 14) / n;
      for (let i = 0; i < n; i++) {
        const x0 = -HX - 7 + i * w, x1 = x0 + w, b = BOARD[i % BOARD.length];
        this.poly([[x0, y, 0], [x1, y, 0], [x1, y, 1.15], [x0, y, 1.15]], b[1], 'rgba(0,0,0,.35)');
        const s = this.P((x0 + x1) / 2, y, 0.58);
        if (s && s.k > 10) { g.fillStyle = '#fff'; g.font = '800 ' + Math.max(8, 0.55 * s.k) + 'px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(b[0], s.x, s.y); }
      }
      [-1, 1].forEach(sd => { const x = sd * (HX + 3.4); for (let i = 0; i < 6; i++) { const y0 = -HY - 2 + i * 12.3, y1 = y0 + 12.3, b = BOARD[(i * 2 + (sd > 0 ? 1 : 0)) % BOARD.length]; this.poly([[x, y0, 0], [x, y1, 0], [x, y1, 1.15], [x, y0, 1.15]], b[1], 'rgba(0,0,0,.35)'); } });
    }
    _pitch() {
      const M = 8;
      this.poly([[-HX - M, -HY - 6, 0], [HX + M, -HY - 6, 0], [HX + M, HY + 6, 0], [-HX - M, HY + 6, 0]], '#1c5f2e');
      const n = 14, w = 2 * HX / n;
      for (let i = 0; i < n; i++) this.poly([[-HX + i * w, -HY, 0], [-HX + (i + 1) * w, -HY, 0], [-HX + (i + 1) * w, HY, 0], [-HX + i * w, HY, 0]], i % 2 ? '#2a8a3e' : '#329c47');
      const L = 0.16, W = '#f6f6f6';
      const line = (a, b, c, d) => this.gline(a, b, c, d, L, W);
      line(-HX, -HY, HX, -HY); line(-HX, HY, HX, HY); line(-HX, -HY, -HX, HY); line(HX, -HY, HX, HY); line(0, -HY, 0, HY);
      const arc = (cx, cy, r, a0, a1, steps) => { let px = cx + r * Math.cos(a0), py = cy + r * Math.sin(a0); for (let i = 1; i <= steps; i++) { const a = a0 + (a1 - a0) * i / steps, x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); line(px, py, x, y); px = x; py = y; } };
      arc(0, 0, 9.15, 0, Math.PI * 2, 44);
      this.poly([[-0.3, -0.3, 0.01], [0.3, -0.3, 0.01], [0.3, 0.3, 0.01], [-0.3, 0.3, 0.01]], W);
      [-1, 1].forEach(s => {
        const x = s * HX, xi = s * (HX - BOX_X), xg = s * (HX - 5.5);
        line(x, -BOX_Y, xi, -BOX_Y); line(xi, -BOX_Y, xi, BOX_Y); line(xi, BOX_Y, x, BOX_Y);
        line(x, -9.16, xg, -9.16); line(xg, -9.16, xg, 9.16); line(xg, 9.16, x, 9.16);
        const ps = s * (HX - 11); this.poly([[ps - 0.25, -0.25, 0.01], [ps + 0.25, -0.25, 0.01], [ps + 0.25, 0.25, 0.01], [ps - 0.25, 0.25, 0.01]], W);
        const a = Math.acos(5.5 / 9.15); if (s < 0) arc(ps, 0, 9.15, -a, a, 14); else arc(ps, 0, 9.15, Math.PI - a, Math.PI + a, 14);
      });
    }
    _goal(s) {
      const gx = s * HX, dep = s * 2.2, col = '#f2f2f2', net = 'rgba(255,255,255,.28)';
      const top = GH, bt = 2.0;
      // شبكة: سقف + جانبين + خلف
      for (let i = 0; i <= 8; i++) { const y = -GW + (2 * GW) * i / 8; this.seg([gx, y, top], [gx + dep, y, bt], 1, net); this.seg([gx + dep, y, bt], [gx + dep, y, 0], 1, net); }
      for (let i = 0; i <= 5; i++) { const z = bt * i / 5; this.seg([gx + dep, -GW, z], [gx + dep, GW, z], 1, net); }
      for (let i = 0; i <= 4; i++) { const t = i / 4; this.seg([gx + dep * t, -GW, top + (bt - top) * t], [gx + dep * t, GW, top + (bt - top) * t], 1, net); this.seg([gx + dep * t, -GW, 0], [gx + dep * t, -GW, top + (bt - top) * t], 1, net); this.seg([gx + dep * t, GW, 0], [gx + dep * t, GW, top + (bt - top) * t], 1, net); }
      const pw = 4; this.seg([gx, -GW, 0], [gx, -GW, GH], pw, col); this.seg([gx, GW, 0], [gx, GW, GH], pw, col); this.seg([gx, -GW, GH], [gx, GW, GH], pw, col);
      this.seg([gx, -GW, GH], [gx + dep, -GW, bt], 2, col); this.seg([gx, GW, GH], [gx + dep, GW, bt], 2, col);
    }
    _flags() {
      [[-HX, -HY], [-HX, HY], [HX, -HY], [HX, HY]].forEach(([x, y]) => { this.seg([x, y, 0], [x, y, 1.5], 2, '#fff'); this.poly([[x, y, 1.5], [x + (x < 0 ? 0.5 : -0.5), y, 1.35], [x, y, 1.2]], '#ffd23f'); });
    }

    // ---------- اللاعبون ----------
    updateAnim(dt, players) {
      for (let i = 0; i < players.length; i++) {
        const p = players[i]; let st = this.anim[i];
        if (!st) st = this.anim[i] = { ph: i, lx: p[0], ly: p[1], sp: 0 };
        const d = Math.hypot(p[0] - st.lx, p[1] - st.ly); st.lx = p[0]; st.ly = p[1];
        const inst = dt > 0 ? Math.min(9, d / dt) : 0; st.sp += (inst - st.sp) * Math.min(1, 10 * dt);
        st.ph += d * 2.4;
      }
    }
    drawPlayer(id, p, me, name) {
      const g = this.g, team = id < 11 ? 0 : 1, idx = id % 11, gk = idx === 0, kit = KIT[team];
      const x = p[0], y = p[1], face = p[2], anim = p[3];
      const base = this.P(x, y, 0); if (!base) return null;
      const st = this.anim[id] || { ph: 0, sp: 0 }, k = base.k;
      if (base.x < -80 || base.x > this.W + 80 || base.y < -150 || base.y > this.H + 80) return base;
      const fx = Math.cos(face), fy = Math.sin(face), px = -fy, py = fx, run = Math.min(1, st.sp / 6.2), t = this.t;
      const sw = Math.sin(st.ph) * 0.55 * run, ph2 = Math.sin(st.ph + Math.PI / 2);
      let hip = [x, y, 0.95], sho = [x + fx * 0.12 * run, y + fy * 0.12 * run, 1.5], head = [x + fx * 0.17 * run, y + fy * 0.17 * run, 1.74];
      let lf = [x + fx * sw + px * 0.14, y + fy * sw + py * 0.14, Math.max(0, ph2) * 0.22 * run], rf = [x - fx * sw - px * 0.14, y - fy * sw - py * 0.14, Math.max(0, -ph2) * 0.22 * run];
      let lh = [x - fx * sw * 0.8 - px * 0.3, y - fy * sw * 0.8 - py * 0.3, 0.95], rh = [x + fx * sw * 0.8 + px * 0.3, y + fy * sw * 0.8 + py * 0.3, 0.95];
      if (gk && anim < 3) { lh = [x + px * 0.5 + fx * 0.15, y + py * 0.5 + fy * 0.15, 1.15]; rh = [x - px * 0.5 + fx * 0.15, y - py * 0.5 + fy * 0.15, 1.15]; }
      if (anim === 3) { rf = [x + fx * 0.95, y + fy * 0.95, 0.28]; sho = [x - fx * 0.1, y - fy * 0.1, 1.5]; }
      else if (anim === 4) {
        hip = [x, y, 0.35]; sho = [x - fx * 0.55, y - fy * 0.55, 0.55]; head = [x - fx * 0.85, y - fy * 0.85, 0.7];
        lf = [x + fx * 1.0 + px * 0.12, y + fy * 1.0 + py * 0.12, 0.12]; rf = [x + fx * 1.25 - px * 0.12, y + fy * 1.25 - py * 0.12, 0.14];
        lh = [x - fx * 0.9 + px * 0.4, y - fy * 0.9 + py * 0.4, 0.3]; rh = [x - fx * 0.9 - px * 0.4, y - fy * 0.9 - py * 0.4, 0.3];
      } else if (anim === 5) {
        const j = Math.abs(Math.sin(t * 9 + id)) * 0.4;
        hip[2] += j; sho[2] += j; head[2] += j; lf[2] += j * 0.9; rf[2] += j * 0.9;
        lh = [x + px * 0.4, y + py * 0.4, 2.1 + j]; rh = [x - px * 0.4, y - py * 0.4, 2.1 + j];
      } else if (anim === 6 || anim === 7) {
        const dv = anim === 6 ? 1 : -1;
        hip = [x, y - dv * 0.2, 0.8]; sho = [x, y + dv * 0.7, 1.05]; head = [x, y + dv * 1.0, 1.1];
        lh = [x + 0.2, y + dv * 1.6, 1.35]; rh = [x - 0.2, y + dv * 1.6, 1.25]; lf = [x + 0.15, y - dv * 0.95, 0.55]; rf = [x - 0.15, y - dv * 0.95, 0.4];
      }
      const pj = a => this.P(a[0], a[1], a[2]);
      const H = pj(hip), S = pj(sho), Hd = pj(head), LF = pj(lf), RF = pj(rf), LH = pj(lh), RH = pj(rh);
      if (!H || !S || !Hd || !LF || !RF || !LH || !RH) return base;
      const shirt = gk ? kit.gk : kit.shirt, shorts = gk ? kit.gkShorts : kit.shorts, socks = gk ? kit.gk : kit.socks, skin = SKIN[id % SKIN.length], hair = HAIR[id % HAIR.length];
      // ظل
      g.fillStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.ellipse(base.x, base.y, 0.5 * k, 0.26 * k, 0, 0, 6.2832); g.fill();
      if (me) { g.strokeStyle = '#ffd23f'; g.lineWidth = Math.max(1.5, 0.08 * k); g.beginPath(); g.ellipse(base.x, base.y, 0.95 * k, 0.5 * k, 0, 0, 6.2832); g.stroke(); }
      g.lineCap = 'round'; g.lineJoin = 'round';
      const ln = (a, b, w, c) => { g.strokeStyle = c; g.lineWidth = Math.max(1.6, w * k); g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke(); };
      // الساقان (الجوارب) + الحذاء
      ln(H, LF, 0.17, socks); ln(H, RF, 0.17, socks);
      ln({ x: LF.x, y: LF.y }, { x: LF.x + (fx * 0.0) * k, y: LF.y + 0.04 * k }, 0.22, '#111'); ln({ x: RF.x, y: RF.y }, { x: RF.x, y: RF.y + 0.04 * k }, 0.22, '#111');
      // السروال
      const sh1 = { x: H.x, y: H.y + (anim === 4 ? 0 : 0.12 * k) }; ln(H, sh1, 0.4, shorts);
      // الجذع
      ln(H, S, 0.46, shirt);
      if (k > 16) { g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = Math.max(1, 0.05 * k); g.beginPath(); g.moveTo(S.x - 0.2 * k, S.y + 0.02 * k); g.lineTo(S.x + 0.2 * k, S.y + 0.02 * k); g.stroke(); }
      // الذراعان
      ln(S, LH, 0.13, skin); ln(S, RH, 0.13, skin);
      // الرأس
      g.fillStyle = skin; g.beginPath(); g.arc(Hd.x, Hd.y, Math.max(2.4, 0.15 * k), 0, 6.2832); g.fill();
      g.fillStyle = hair; g.beginPath(); g.arc(Hd.x, Hd.y - 0.02 * k, Math.max(2.4, 0.15 * k), Math.PI, 0); g.fill();
      if (k > 24 && anim < 4) { g.fillStyle = '#fff'; g.font = '800 ' + (0.3 * k) + 'px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(ROLE_NUM[idx]), (H.x + S.x) / 2, (H.y + S.y) / 2); }
      return { x: Hd.x, y: Hd.y, k, d: base.d };
    }
    drawName(info, name, team, me, extra) {
      if (!info) return; const g = this.g, k = info.k;
      const fs = clamp(0.42 * k, 10, 17); g.font = '700 ' + fs + 'px "Cairo","Segoe UI",Tahoma,sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      const w = g.measureText(name).width + 12, h = fs + 6, x = info.x, y = info.y - 0.5 * k - 6;
      g.fillStyle = 'rgba(8,14,28,.78)'; this._rr(x - w / 2, y - h / 2, w, h, h / 2); g.fill();
      g.fillStyle = KIT[team].shirt; g.fillRect(x - w / 2 + 3, y + h / 2 - 3, w - 6, 2);
      g.fillStyle = me ? '#ffd23f' : '#fff'; g.fillText(name, x, y + 0.5);
      if (me) { g.fillStyle = '#ffd23f'; const ay = y - h / 2 - 3 - Math.abs(Math.sin(this.t * 5)) * 3; g.beginPath(); g.moveTo(x - 6, ay - 8); g.lineTo(x + 6, ay - 8); g.lineTo(x, ay); g.closePath(); g.fill(); }
    }
    _rr(x, y, w, h, r) { const g = this.g; g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
    drawBall(b) {
      const g = this.g, base = this.P(b[0], b[1], 0), c = this.P(b[0], b[1], b[2] + 0.22); if (!base || !c) return null;
      const r = Math.max(3, 0.24 * c.k), hgt = Math.min(1, b[2] / 6);
      g.fillStyle = 'rgba(0,0,0,' + (0.38 - hgt * 0.22) + ')'; g.beginPath(); g.ellipse(base.x, base.y, r * (1 + hgt * 0.5), r * 0.5 * (1 + hgt * 0.5), 0, 0, 6.2832); g.fill();
      const gr = g.createRadialGradient(c.x - r * 0.35, c.y - r * 0.35, r * 0.15, c.x, c.y, r); gr.addColorStop(0, '#ffffff'); gr.addColorStop(1, '#c9ced6');
      g.fillStyle = gr; g.beginPath(); g.arc(c.x, c.y, r, 0, 6.2832); g.fill();
      g.fillStyle = '#1b1f27'; const sp = b[4] || 0;
      for (let i = 0; i < 5; i++) { const a = sp * 1.6 + i * 1.2566, rr = r * 0.52; g.beginPath(); g.arc(c.x + Math.cos(a) * rr * 0.9, c.y + Math.sin(a) * rr * 0.9 * (0.8 + 0.2 * Math.cos(sp)), r * 0.2, 0, 6.2832); g.fill(); }
      g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1; g.beginPath(); g.arc(c.x, c.y, r, 0, 6.2832); g.stroke();
      return { d: c.d };
    }

    /* state: {players:[[x,y,face,anim,human]×22], ball:[x,y,z,owner,spin], meId, names:{pid:name}, dt} */
    render(state, dt) {
      this.t += dt; this.shake = Math.max(0, this.shake - dt * 1.6); this.exc += (0.25 - this.exc) * Math.min(1, dt * 0.5);
      const g = this.g; g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      this._prep(); this.drawScene();
      const pl = state.players; this.updateAnim(dt, pl);
      const items = [];
      for (let i = 0; i < pl.length; i++) { const b = this.P(pl[i][0], pl[i][1], 0); if (b) items.push({ k: 'p', i, d: b.d }); }
      const bb = this.P(state.ball[0], state.ball[1], 0); if (bb) items.push({ k: 'b', d: bb.d - 0.3 });
      items.sort((a, b) => b.d - a.d);
      const tags = [];
      for (const it of items) {
        if (it.k === 'b') this.drawBall(state.ball);
        else { const me = it.i === state.meId; const info = this.drawPlayer(it.i, pl[it.i], me); if (info && (pl[it.i][4] || me) && state.names && state.names[it.i]) tags.push([info, state.names[it.i], it.i < 11 ? 0 : 1, me]); }
      }
      tags.forEach(t => this.drawName(t[0], t[1], t[2], t[3]));
      // قصاصات الاحتفال
      for (let i = this.parts.length - 1; i >= 0; i--) {
        const p = this.parts[i]; p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 30 * dt; p.r += p.vr * dt;
        if (p.life <= 0 || p.y > this.H + 30) { this.parts.splice(i, 1); continue; }
        g.save(); g.translate(p.x, p.y); g.rotate(p.r); g.fillStyle = p.c; g.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); g.restore();
      }
      const vg = g.createRadialGradient(this.W / 2, this.H / 2, Math.min(this.W, this.H) * 0.45, this.W / 2, this.H / 2, Math.max(this.W, this.H) * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.45)'); g.fillStyle = vg; g.fillRect(0, 0, this.W, this.H);
    }
  }

  // ---------- خريطة مصغرة ----------
  function drawRadar(cv, players, ball, flip, meId) {
    const g = cv.getContext('2d'), w = cv.width, h = cv.height; g.clearRect(0, 0, w, h);
    g.fillStyle = 'rgba(10,40,20,.78)'; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1; g.strokeRect(1, 1, w - 2, h - 2);
    g.beginPath(); g.moveTo(w / 2, 0); g.lineTo(w / 2, h); g.stroke(); g.beginPath(); g.arc(w / 2, h / 2, h * 0.14, 0, 6.2832); g.stroke();
    g.strokeRect(1, h * 0.2, w * 0.15, h * 0.6); g.strokeRect(w * 0.85 - 1, h * 0.2, w * 0.15, h * 0.6);
    const X = x => (flip ? -x : x) / (HX * 2) * w + w / 2, Y = y => h / 2 - (flip ? -y : y) / (HY * 2) * h;
    players.forEach((p, i) => { g.fillStyle = KIT[i < 11 ? 0 : 1].shirt; g.beginPath(); g.arc(X(p[0]), Y(p[1]), i === meId ? 4 : 2.6, 0, 6.2832); g.fill(); if (i === meId) { g.strokeStyle = '#ffd23f'; g.lineWidth = 2; g.stroke(); } });
    g.fillStyle = '#fff'; g.beginPath(); g.arc(X(ball[0]), Y(ball[1]), 3, 0, 6.2832); g.fill();
  }

  // ---------- شاشة التشكيل ----------
  function drawLineup(cv, lineup) {
    const g = cv.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2), r = cv.getBoundingClientRect();
    const w = Math.max(10, r.width), h = Math.max(10, r.height); cv.width = w * dpr; cv.height = h * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const gr = g.createLinearGradient(0, 0, w, 0); gr.addColorStop(0, '#2a8a3e'); gr.addColorStop(1, '#329c47'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 14; i += 2) { g.fillStyle = 'rgba(255,255,255,.045)'; g.fillRect(i * w / 14, 0, w / 14, h); }
    g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 2; g.strokeRect(6, 6, w - 12, h - 12);
    g.beginPath(); g.moveTo(w / 2, 6); g.lineTo(w / 2, h - 6); g.stroke(); g.beginPath(); g.arc(w / 2, h / 2, h * 0.14, 0, 6.2832); g.stroke();
    g.strokeRect(6, h * 0.2, w * 0.12, h * 0.6); g.strokeRect(w - 6 - w * 0.12, h * 0.2, w * 0.12, h * 0.6);
    if (!lineup) return;
    const fs = clamp(w / 70, 9, 14); g.textAlign = 'center';
    lineup.forEach((team, t) => team.forEach(p => {
      const u = Math.min(p.u, 0.46) / 0.5; // 0..~0.92 داخل نصف الملعب
      const lx = (t === 0 ? 0.06 + u * 0.4 : 0.94 - u * 0.4) * w, ly = h / 2 + (t === 0 ? 1 : -1) * p.v * h * 0.4 * (t === 0 ? -1 : 1) * -1;
      const x = lx, y = h / 2 + (t === 0 ? p.v : -p.v) * h * 0.42;
      const rad = clamp(h / 24, 7, 13);
      g.fillStyle = p.role === 'GK' ? KIT[t].gk : KIT[t].shirt; g.beginPath(); g.arc(x, y, rad, 0, 6.2832); g.fill();
      g.lineWidth = p.name ? 3 : 1.5; g.strokeStyle = p.name ? '#ffd23f' : 'rgba(255,255,255,.7)'; g.stroke();
      g.fillStyle = p.role === 'GK' ? '#111' : '#fff'; g.font = '800 ' + (rad * 0.95) + 'px system-ui'; g.textBaseline = 'middle'; g.fillText(p.num, x, y + 0.5);
      g.textBaseline = 'alphabetic'; g.font = (p.name ? '700 ' : '500 ') + fs + 'px "Cairo","Segoe UI",Tahoma,sans-serif';
      const label = p.name || 'AI', tw = g.measureText(label).width + 8;
      g.fillStyle = p.name ? 'rgba(8,14,28,.85)' : 'rgba(8,14,28,.45)'; g.fillRect(x - tw / 2, y + rad + 2, tw, fs + 5);
      g.fillStyle = p.name ? '#fff' : 'rgba(255,255,255,.6)'; g.fillText(label, x, y + rad + fs + 2);
    }));
  }

  root.Render = { Field3D, drawRadar, drawLineup, KIT, TEAM_NAMES };
})(window);
