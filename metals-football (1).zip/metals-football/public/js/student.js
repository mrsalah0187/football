/* صفحة الطالب: انضمام ← جدول دوري ← اختيار فريق ← انتظار ← مباراة ← نتائج */
(function () {
  'use strict';
  const { $, esc, fmt, TEAMS } = Common;
  const SAVE = 'mfc_session';
  const S = { me: null, room: null, introDone: false, pendingElement: null, wantTeamScreen: false, view: null, lastQ: null, answered: null, shown: null, lastSnap: null, shot: false };

  const screens = ['s-join', 's-intro', 's-team', 's-lobby', 'game', 's-end'];
  function show(id) { screens.forEach(s => $(s).classList.toggle('hidden', s !== id)); if (id === 'game') { if (!S.view) startGame(); else S.view.field.resize(); } if (id === 's-lobby' || id === 's-join' || id === 's-team') paintBgs(); if (id === 's-intro') drawTable(); }
  const load = () => { try { return JSON.parse(localStorage.getItem(SAVE) || 'null'); } catch (e) { return null; } };
  const save = o => { try { localStorage.setItem(SAVE, JSON.stringify(o)); } catch (e) { /* */ } };
  const clear = () => { try { localStorage.removeItem(SAVE); } catch (e) { /* */ } };

  // ---------- خلفيات ----------
  function paintBgs() { ['bg-join', 'bg-team'].forEach(id => { const c = $(id); if (c && c.offsetWidth) { Render.drawLineup(c, null); const g = c.getContext('2d'); g.fillStyle = 'rgba(4,10,24,.72)'; g.fillRect(0, 0, c.offsetWidth, c.offsetHeight); } }); if (S.room && !$('s-lobby').classList.contains('hidden')) Render.drawLineup($('lineupCv'), S.room.lineup); }
  addEventListener('resize', () => { paintBgs(); drawTable(); });

  // ---------- الاتصال ----------
  const conn = Common.connect({
    open() { $('conn').classList.add('hidden'); const s = load(); if (s) conn.send({ t: 'join', pin: s.pin, token: s.token }); },
    close() { $('conn').classList.remove('hidden'); },
    msg(m) {
      switch (m.t) {
        case 'joined': S.me = m; save({ pin: m.pin, token: m.token }); if (m.element) { S.introDone = true; } break;
        case 'room': S.room = m; if (m.me) S.me = Object.assign(S.me || {}, m.me); route(); break;
        case 'element': onElement(m.id); break;
        case 'err': onErr(m); break;
        case 'kicked': clear(); alert('أخرجك المعلم من المباراة'); location.reload(); break;
        case 's': onSnap(m); break;
        default: break;
      }
    }
  });

  function onErr(m) {
    if (m.code === 'team_full') { $('teamErr').textContent = m.msg; $('tb0').disabled = false; return; }
    if (m.code === 'no_room' && load()) { clear(); S.me = null; show('s-join'); }
    $('joinErr').textContent = m.msg || 'حدث خطأ';
  }

  // ---------- الانضمام ----------
  $('btnJoin').onclick = () => {
    Sound.init(); Sound.play('click');
    const name = $('inName').value.trim(), pin = $('inPin').value.trim();
    if (!name) return ($('joinErr').textContent = 'اكتب اسمك أولًا');
    if (!/^\d{6}$/.test(pin)) return ($('joinErr').textContent = 'رمز المباراة مكوّن من 6 أرقام');
    $('joinErr').textContent = ''; clear(); conn.send({ t: 'join', pin, name });
  };
  $('inPin').addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, ''); });
  $('inPin').addEventListener('keydown', e => { if (e.key === 'Enter') $('btnJoin').click(); });
  $('inName').addEventListener('keydown', e => { if (e.key === 'Enter') $('inPin').focus(); });
  try { const p = new URLSearchParams(location.search).get('pin'); if (p) $('inPin').value = p.replace(/\D/g, '').slice(0, 6); } catch (e) { /* */ }

  // ---------- التوجيه ----------
  function route() {
    const r = S.room, me = S.me; if (!r || !me) return;
    const st = r.status;
    if (!$('elModal').classList.contains('hidden')) return;      // لا نقاطع بطاقة العنصر
    if (st === 'finished') { show('s-end'); if (S.lastSnap && S.lastSnap.res) $('s-end').innerHTML = Common.endHTML(S.lastSnap.res) + '<div class="mut" style="margin:14px 0">بانتظار المعلم لبدء مباراة جديدة…</div>'; return; }
    const hasTeam = me.team === 0 || me.team === 1;
    if (st === 'lobby') {
      if (!S.introDone && !me.element) return show('s-intro');
      if (!hasTeam || S.wantTeamScreen) return showTeam();
      return showLobby();
    }
    if (!hasTeam) return showTeam();
    show('game');
  }
  function showTeam() {
    show('s-team'); const r = S.room, me = S.me;
    $('teamName').textContent = 'أهلًا ' + me.name + '! اختر الفريق الذي تريد اللعب معه';
    [0, 1].forEach(t => { $('tc' + t).textContent = r.counts[t] + ' / 11 لاعبًا'; $('tb' + t).classList.toggle('sel', me.team === t); $('tb' + t).disabled = r.counts[t] >= 11 && me.team !== t; });
  }
  [0, 1].forEach(t => { $('tb' + t).onclick = () => { Sound.init(); Sound.play('beep'); $('teamErr').textContent = ''; S.wantTeamScreen = false; conn.send({ t: 'pick_team', team: t }); }; });
  function showLobby() {
    show('s-lobby'); const r = S.room, me = S.me;
    Render.drawLineup($('lineupCv'), r.lineup);
    $('lobbyInfo').textContent = 'أنت في ' + TEAMS[me.team] + ' · الطلاب: ' + r.students.length + ' · المدة: ' + r.duration / 60 + ' دقائق · اللاعبون غير المشاركين يتحكم بهم الكمبيوتر (AI)';
  }
  $('btnSwitch').onclick = () => { S.wantTeamScreen = true; route(); };

  // ---------- الجدول الدوري + التسديد ----------
  const tcv = $('ptable'); const T = { ball: null, anim: null, flash: null, drag: null, cells: [] };
  function layout() {
    const r = tcv.getBoundingClientRect(), W = r.width, H = r.height, dpr = Math.min(devicePixelRatio || 1, 2);
    if (tcv.width !== Math.round(W * dpr)) { tcv.width = Math.round(W * dpr); tcv.height = Math.round(H * dpr); }
    const cw = Math.min(W / 19.2, (H - 70) / 10.6), gx = (W - cw * 18) / 2, gy = 8;
    return { W, H, dpr, cw, gx, gy };
  }
  function cellRect(L, c) { return { x: L.gx + c.col * L.cw, y: L.gy + c.row * L.cw + (c.row >= 8 ? L.cw * 0.5 : 0), w: L.cw - 2, h: L.cw - 2 }; }
  function drawTable() {
    if ($('s-intro').classList.contains('hidden')) return;
    const L = layout(), g = tcv.getContext('2d'); g.setTransform(L.dpr, 0, 0, L.dpr, 0, 0); g.clearRect(0, 0, L.W, L.H);
    const now = performance.now();
    MData.CELLS.forEach(c => {
      const R = cellRect(L, c), col = MData.CAT_COLOR[c.cat], isEl = !!MData.ELEMENTS[c.sym] && c.metal;
      g.globalAlpha = c.cat === 'ph' ? 0.35 : c.metal ? 1 : 0.35; g.fillStyle = col; g.fillRect(R.x, R.y, R.w, R.h);
      g.globalAlpha = 1;
      if (isEl) { g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1.5; g.strokeRect(R.x, R.y, R.w, R.h); }
      if (T.flash && T.flash.sym === c.sym) { const a = 0.5 + 0.5 * Math.sin((now - T.flash.t) / 90); g.fillStyle = 'rgba(255,255,255,' + (0.4 + a * 0.5) + ')'; g.fillRect(R.x - 2, R.y - 2, R.w + 4, R.h + 4); g.strokeStyle = '#fff'; g.lineWidth = 3; g.strokeRect(R.x - 2, R.y - 2, R.w + 4, R.h + 4); }
      if (L.cw > 14) { g.fillStyle = c.metal ? (c.cat === 'transition' || c.cat === 'alkaline' ? '#1b1500' : '#fff') : '#cfd8ea'; g.font = '800 ' + Math.max(8, L.cw * 0.36) + 'px system-ui,sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; if (c.cat !== 'ph') g.fillText(c.sym, R.x + R.w / 2, R.y + R.h / 2); }
    });
    // الكرة
    const bx = L.W / 2, by = L.H - 30;
    if (!T.ball) T.ball = { x: bx, y: by, s: 1 };
    if (T.anim) {
      const a = T.anim, k = Math.min(1, (now - a.t0) / a.dur), e = 1 - Math.pow(1 - k, 3);
      T.ball.x = a.x0 + (a.x1 - a.x0) * e; T.ball.y = a.y0 + (a.y1 - a.y0) * e - Math.sin(k * Math.PI) * 60; T.ball.s = 1 - 0.5 * e;
      if (k >= 1) { const cb = a.done; T.anim = null; cb && cb(); }
    } else if (!T.flash) { T.ball.x = bx; T.ball.y = by; T.ball.s = 1; }
    const r = 17 * T.ball.s;
    if (T.drag) { g.strokeStyle = 'rgba(255,255,255,.7)'; g.setLineDash([6, 6]); g.beginPath(); g.moveTo(bx, by); g.lineTo(T.drag.x, T.drag.y); g.stroke(); g.setLineDash([]); }
    g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(T.ball.x, T.ball.y + r * 0.9, r, r * 0.35, 0, 0, 6.3); g.fill();
    const gr = g.createRadialGradient(T.ball.x - r * 0.3, T.ball.y - r * 0.3, 2, T.ball.x, T.ball.y, r); gr.addColorStop(0, '#fff'); gr.addColorStop(1, '#bfc6d2'); g.fillStyle = gr; g.beginPath(); g.arc(T.ball.x, T.ball.y, r, 0, 6.3); g.fill();
    g.fillStyle = '#1b1f27'; for (let i = 0; i < 5; i++) { const an = now / 300 * (T.anim ? 3 : 0) + i * 1.2566; g.beginPath(); g.arc(T.ball.x + Math.cos(an) * r * 0.5, T.ball.y + Math.sin(an) * r * 0.5, r * 0.2, 0, 6.3); g.fill(); }
  }
  (function loop() { if (!$('s-intro').classList.contains('hidden')) drawTable(); requestAnimationFrame(loop); })();
  function shoot(px, py) {
    if (S.shot || T.anim) return; S.shot = true; Sound.init(); Sound.play('shot');
    T.target = { x: px, y: py }; $('introHint').textContent = '… الكرة في الطريق!';
    conn.send({ t: 'intro_hit' });
    // احتياط: لو لم يصل الرد
    setTimeout(() => { if (S.shot && !T.anim && !S.pendingElement) { S.shot = false; $('introHint').textContent = 'تعذّر الاتصال، حاول مرة أخرى'; } }, 4000);
  }
  function pt(e) { const r = tcv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  tcv.addEventListener('pointerdown', e => { if (S.shot) return; T.drag = pt(e); tcv.setPointerCapture(e.pointerId); });
  tcv.addEventListener('pointermove', e => { if (T.drag) T.drag = pt(e); });
  tcv.addEventListener('pointerup', e => { if (!T.drag) return; const p = pt(e); T.drag = null; shoot(p.x, p.y); });
  tcv.addEventListener('pointercancel', () => { T.drag = null; });

  function onElement(id) {
    S.pendingElement = id; if (S.me) S.me.element = id;
    const L = layout(), cell = MData.CELLS.find(c => c.sym === id), R = cellRect(L, cell);
    if (!S.shot) S.shot = true;
    T.anim = { t0: performance.now(), dur: 900, x0: T.ball ? T.ball.x : L.W / 2, y0: T.ball ? T.ball.y : L.H - 30, x1: R.x + R.w / 2, y1: R.y + R.h / 2, done() { Sound.play('correct'); T.flash = { sym: id, t: performance.now() }; setTimeout(() => showElementCard(id), 900); } };
    drawTable();
  }
  function showElementCard(id) {
    $('elHolder').innerHTML = Common.elementCardHTML(id); $('elModal').classList.remove('hidden'); Sound.play('beep');
    $('btnElNext').textContent = S.me && (S.me.team === 0 || S.me.team === 1) ? 'متابعة ⟵' : 'اختيار الفريق ⟵';
  }
  $('btnElNext').onclick = () => { $('elModal').classList.add('hidden'); S.introDone = true; T.flash = null; T.ball = null; S.shot = false; route(); };

  // ---------- المباراة ----------
  function startGame() {
    S.view = new Common.GameView($('field'), { flip: S.me.team === 1, meId: S.me.pid, radar: $('radar'), onEvent: onGameEvent });
    $('nmA').textContent = 'الأحمر'; $('nmB').textContent = 'الأزرق';
    if ('ontouchstart' in window || (matchMedia && matchMedia('(pointer:coarse)').matches)) $('game').classList.add('touch');
    startInput();
  }
  function toast(t, ms) { const el = $('toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove('on'), ms || 1800); }
  function onGameEvent(e, d) {
    if (e === 'goal') Sound.play('goal'); else Sound.play(e);
    if (e === 'save') toast('🧤 تصدّي رائع من الحارس!'); else if (e === 'miss') toast('😬 التسديدة خارج المرمى'); else if (e === 'out') toast('الكرة خارج الملعب');
  }
  function onSnap(s) {
    S.lastSnap = s; Sound.crowd(s.st === 'playing' || s.st === 'goal');
    if (s.st === 'finished' && s.res) { $('s-end').innerHTML = Common.endHTML(s.res) + '<div class="mut" style="margin:14px 0">بانتظار المعلم لبدء مباراة جديدة…</div>'; if (!$('s-end').classList.contains('hidden')) return; if (S.me && (S.me.team === 0 || S.me.team === 1)) { show('s-end'); Sound.play('whistle'); } return; }
    if (!S.view || $('game').classList.contains('hidden')) return;
    if (S.room) S.view.names = S.room.names || {};
    S.view.feed(s);
    $('scA').textContent = s.sc[0]; $('scB').textContent = s.sc[1]; $('clk').textContent = fmt(s.dur - s.clk);
    $('half').textContent = s.st === 'paused' ? 'PAUSED' : s.st === 'question' || s.st === 'qresult' ? '❓ سؤال' : 'LIVE';
    const st = S.stats; if (S.me) { $('meName').innerHTML = '<b>' + esc(S.me.name) + '</b> · ' + TEAMS[S.me.team]; }
    // الشعارات
    const b = $('banner');
    if (s.st === 'goal' && s.goal) { const key = 'g' + s.sc.join('-'); if (S.shown !== key) { S.shown = key; b.innerHTML = '<div class="big">GOAL!</div><div class="sub">⚽ ' + esc(s.goal.scorer) + ' — ' + TEAMS[s.goal.team] + '</div>'; } }
    else if (s.st === 'countdown') { const k = 'c' + s.cd; if (S.shown !== k) { S.shown = k; b.innerHTML = '<div id="cdown">' + s.cd + '</div>'; Sound.play('tick'); } }
    else if (S.shown) { S.shown = null; b.innerHTML = ''; }
    const ov = $('status-ov'); ov.classList.toggle('hidden', s.st !== 'paused'); if (s.st === 'paused') ov.textContent = '⏸ المباراة متوقفة مؤقتًا من المعلم';
    renderQuestion(s);
  }

  // ---------- السؤال ----------
  function renderQuestion(s) {
    const qp = $('qpanel'), q = s.q;
    if (!q || !(s.st === 'question' || s.st === 'qresult')) { qp.classList.add('hidden'); S.lastQ = null; S.qKey = null; return; }
    const mine = q.ans.includes(S.me.id);
    if (!mine) {
      qp.classList.add('hidden');
      toast((q.res ? (q.res.ok ? '✅ ' : '❌ ') : '❓ ') + TEAMS[q.team] + (q.res ? (q.res.ok ? ' أجاب بشكل صحيح!' : ' أخطأ — تضيع الفرصة') : ' يجيب على سؤال علمي… ' + Math.ceil(q.left) + ' ث'), 1200);
      return;
    }
    const key = q.id + ':' + (q.res ? 'r' : 'q');
    if (S.qKey !== key) {
      S.qKey = key; if (!S.lastQ || S.lastQ !== q.id) { S.lastQ = q.id; S.answered = null; }
      const L = ['أ', 'ب', 'ج', 'د'], lv = ['', 'سهل', 'متوسط', 'صعب'][q.lvl];
      qp.innerHTML = '<div class="qbox"><div class="qtop"><span class="qtag">❓ سؤال علمي — ' + (S.me.team === q.team ? 'لتسجيل هدف' : '') + '</span><span class="qtag" style="background:rgba(255,255,255,.1);color:#fff">' + lv + '</span><span id="qleft" style="font-weight:800"></span></div><div class="qtimer"><i id="qbar"></i></div><div class="qtext">' + esc(q.text) + '</div><div class="qopts">' +
        q.opts.map((o, i) => '<button class="qopt" data-i="' + i + '"><span class="lt">' + L[i] + '</span><span>' + esc(o) + '</span></button>').join('') + '</div><div class="qnote" id="qnote"></div></div>';
      qp.classList.remove('hidden');
      qp.querySelectorAll('.qopt').forEach(b => b.onclick = () => {
        if (S.answered !== null || (S.lastSnap && S.lastSnap.q && S.lastSnap.q.res)) return; Sound.init();
        S.answered = +b.dataset.i; b.style.borderColor = 'var(--gold)'; qp.querySelectorAll('.qopt').forEach(x => x.classList.toggle('dim', x !== b));
        $('qnote').textContent = '⏳ تم إرسال إجابتك…'; conn.send({ t: 'answer', qid: q.id, choice: S.answered });
      });
    }
    $('qbar').style.width = (q.left / q.total * 100) + '%'; $('qleft').textContent = '⏱ ' + Math.ceil(q.left) + ' ث';
    if (q.res) {
      qp.querySelectorAll('.qopt').forEach((b, i) => { b.classList.remove('dim'); if (i === q.res.right) b.classList.add('right'); else if (i === q.res.choice) b.classList.add('wrong'); else b.classList.add('dim'); });
      $('qnote').innerHTML = q.res.timeout ? '⌛ انتهى الوقت! ضاعت الفرصة' : q.res.ok ? '<span style="color:var(--green)">✅ إجابة صحيحة! سدّد الكرة…</span>' : '<span style="color:var(--red)">❌ إجابة خاطئة — الكرة للخصم</span>';
      if (q.res.sid === S.me.id) { const me = S.me; /* إحصاءات شخصية */ me._ok = (me._ok || 0) + 0; }
    }
  }
  // عدّاد شخصي للإجابات (تقريبي من الأحداث)
  let okN = 0, badN = 0, lastRes = null;
  setInterval(() => { const s = S.lastSnap; if (!s || !s.q || !s.q.res || !S.me) return; const k = s.q.id; if (lastRes === k) return; lastRes = k; if (s.q.res.sid === S.me.id) { if (s.q.res.ok) okN++; else badN++; $('meOk').textContent = okN; $('meBad').textContent = badN; } }, 150);

  // ---------- التحكم ----------
  const keys = {}; const touch = { ax: 0, ay: 0, run: false }; let pad = { ax: 0, ay: 0, run: false }; const padPrev = {};
  function act(a) { conn.send({ t: 'act', a }); }
  function startInput() {
    addEventListener('keydown', e => {
      if ($('game').classList.contains('hidden') || e.target.tagName === 'INPUT') return;
      const k = e.code; if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(k)) e.preventDefault();
      if (keys[k]) return; keys[k] = true; Sound.init();
      if (k === 'Space') act('pass'); else if (k === 'KeyJ') act('shoot'); else if (k === 'KeyK') act('through'); else if (k === 'KeyL') act('tackle');
      // اختيار الإجابة بالأرقام / الحروف
      if (S.lastSnap && S.lastSnap.q && S.lastSnap.st === 'question' && S.answered === null) { const m = { Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3 }[k]; if (m !== undefined) { const b = document.querySelectorAll('.qopt')[m]; if (b) b.click(); } }
    });
    addEventListener('keyup', e => { keys[e.code] = false; });
    addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
    // أزرار اللمس
    document.querySelectorAll('.ab').forEach(b => b.addEventListener('pointerdown', e => { e.preventDefault(); Sound.init(); act(b.dataset.a); b.style.transform = 'scale(.9)'; }));
    document.querySelectorAll('.ab').forEach(b => ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => b.addEventListener(ev, () => { b.style.transform = ''; })));
    const rb = $('runbtn'); rb.addEventListener('pointerdown', e => { e.preventDefault(); touch.run = true; }); ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => rb.addEventListener(ev, () => { touch.run = false; }));
    const joy = $('joy'), knob = joy.firstElementChild; let jid = null;
    const jmove = e => { const r = joy.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2; let dx = e.clientX - cx, dy = e.clientY - cy; const R = r.width / 2, l = Math.hypot(dx, dy); if (l > R) { dx = dx / l * R; dy = dy / l * R; } knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; touch.ax = dx / R; touch.ay = -dy / R; };
    joy.addEventListener('pointerdown', e => { e.preventDefault(); jid = e.pointerId; joy.setPointerCapture(jid); jmove(e); });
    joy.addEventListener('pointermove', e => { if (e.pointerId === jid) jmove(e); });
    const jend = e => { if (e.pointerId !== jid) return; jid = null; touch.ax = touch.ay = 0; knob.style.transform = ''; };
    joy.addEventListener('pointerup', jend); joy.addEventListener('pointercancel', jend);
    // أزرار الصوت وملء الشاشة
    $('btnMute').onclick = () => { Sound.setMuted(!Sound.isMuted()); $('btnMute').textContent = Sound.isMuted() ? '🔇' : '🔊'; };
    $('btnFs').onclick = () => { const d = document; if (!d.fullscreenElement) (d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen || (() => { })).call(d.documentElement); else d.exitFullscreen(); };
    let lastSent = '', lastT = 0;
    setInterval(() => {
      if ($('game').classList.contains('hidden')) return;
      pollPad();
      let ax = 0, ay = 0, run = false;
      if (keys.KeyD || keys.ArrowRight) ax += 1; if (keys.KeyA || keys.ArrowLeft) ax -= 1;
      if (keys.KeyW || keys.ArrowUp) ay += 1; if (keys.KeyS || keys.ArrowDown) ay -= 1;
      run = !!(keys.ShiftLeft || keys.ShiftRight);
      if (!ax && !ay) { ax = touch.ax; ay = touch.ay; }
      if (!ax && !ay) { ax = pad.ax; ay = pad.ay; }
      run = run || touch.run || pad.run;
      const fl = S.me && S.me.team === 1 ? -1 : 1; ax *= fl; ay *= fl;
      const o = { t: 'in', ax: +ax.toFixed(2), ay: +ay.toFixed(2), sp: run ? 1 : 0 }, str = JSON.stringify(o), now = performance.now();
      if (str !== lastSent || now - lastT > 250) { lastSent = str; lastT = now; conn.send(o); }
    }, 50);
  }
  function pollPad() {
    const gp = (navigator.getGamepads ? navigator.getGamepads() : []); let g = null; for (const x of gp) if (x && x.connected) { g = x; break; }
    if (!g) { pad = { ax: 0, ay: 0, run: false }; return; }
    let ax = g.axes[0] || 0, ay = -(g.axes[1] || 0); if (Math.hypot(ax, ay) < 0.18) { ax = 0; ay = 0; }
    if (g.buttons[14] && g.buttons[14].pressed) ax = -1; if (g.buttons[15] && g.buttons[15].pressed) ax = 1; if (g.buttons[12] && g.buttons[12].pressed) ay = 1; if (g.buttons[13] && g.buttons[13].pressed) ay = -1;
    pad = { ax, ay, run: !!(g.buttons[7] && (g.buttons[7].pressed || g.buttons[7].value > 0.4)) };
    const map = { 0: 'pass', 2: 'shoot', 3: 'through', 1: 'tackle' };       // X تمرير، مربع تسديد، مثلث بينية، دائرة تدخل
    for (const b in map) { const p = !!(g.buttons[b] && g.buttons[b].pressed); if (p && !padPrev[b]) { Sound.init(); act(map[b]); } padPrev[b] = p; }
    // اختيار الإجابة بالأزرار أثناء السؤال
    if (S.lastSnap && S.lastSnap.st === 'question' && S.answered === null) { const pm = { 0: 0, 1: 1, 2: 2, 3: 3 }; for (const b in pm) { const p = !!(g.buttons[b] && g.buttons[b].pressed); if (p && !padPrev['q' + b]) { const el = document.querySelectorAll('.qopt')[pm[b]]; if (el) el.click(); } padPrev['q' + b] = p; } }
  }
  document.addEventListener('pointerdown', () => Sound.init(), { once: true });
  setTimeout(paintBgs, 50);
})();
