'use strict';
/* اختبار تكامل: معلم + طلاب افتراضيون عبر WebSocket حقيقي. تشغيل: node test/bots.js [url] */
const WebSocket = require('ws');
const URL = process.argv[2] || 'ws://localhost:' + (process.env.PORT || 3000) + '/ws';
const results = []; const ok = (c, m) => { results.push([!!c, m]); console.log((c ? '  ✔ ' : '  ✘ ') + m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

function client(name) {
  const ws = new WebSocket(URL); const c = { ws, name, snaps: [], room: null, msgs: [], me: null, errs: [] };
  c.ready = new Promise(r => ws.on('open', r));
  ws.on('message', raw => { const m = JSON.parse(raw); c.msgs.push(m.t);
    if (m.t === 's') c.snaps.push(m); else if (m.t === 'room') c.room = m; else if (m.t === 'joined') c.me = m; else if (m.t === 'err') c.errs.push(m); else c[m.t] = m; });
  c.send = o => ws.send(JSON.stringify(o));
  c.wait = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (fn()) return true; await sleep(30); } return false; };
  return c;
}

(async () => {
  console.log('== اختبار البوتات على', URL);
  const host = client('host'); await host.ready;
  host.send({ t: 'host_create' });
  ok(await host.wait(() => host.host_ok), 'المعلم أنشأ مباراة وحصل على PIN: ' + (host.host_ok && host.host_ok.pin));
  const pin = host.host_ok.pin;

  // انضمام برمز خاطئ
  const bad = client('bad'); await bad.ready; bad.send({ t: 'join', pin: '000000', name: 'x' });
  ok(await bad.wait(() => bad.errs.length), 'رمز PIN خاطئ يُرفض'); bad.ws.close();

  const names = ['أحمد', 'سارة', 'خالد', 'نورة', 'فهد', 'ريم'];
  const students = [];
  for (const n of names) { const s = client(n); await s.ready; s.send({ t: 'join', pin, name: n }); students.push(s); }
  ok(await students[5].wait(() => students[5].me), 'جميع الطلاب انضموا');
  ok(host.room && host.room.students.length === 6, 'المعلم يرى 6 طلاب في القائمة');

  // آلية الجدول الدوري: السيرفر يختار عنصرًا عشوائيًا من الفلزات الاثنا عشر
  const IDS = 'Fe Cu Al Au Ag Na K Mg Ca Zn Li Sn'.split(' ');
  students.forEach(s => s.send({ t: 'intro_hit' }));
  ok(await students[5].wait(() => students[5].element), 'كل طالب استلم عنصرًا من الفلزات: ' + students.map(s => s.element && s.element.id).join(','));
  ok(students.every(s => s.element && IDS.includes(s.element.id)), 'العناصر المُختارة ضمن قائمة الفلزات المطلوبة');

  // اختيار الفرق
  students.forEach((s, i) => s.send({ t: 'pick_team', team: i < 3 ? 0 : 1 }));
  await sleep(400);
  ok(host.room.counts[0] === 3 && host.room.counts[1] === 3, 'توزيع الفرق: ' + host.room.counts.join(' / '));
  ok(host.room.lineup[0].filter(p => p.name).length === 3, 'التشكيل يعرض أسماء الطلاب ويُكمل الباقي بالكمبيوتر');

  // لا تبدأ المباراة قبل ضغط المعلم
  await sleep(500);
  ok(students[0].snaps.length === 0, 'لا بث للمباراة قبل ضغط START');
  const startAt = Date.now();
  host.send({ t: 'host_cmd', cmd: 'duration', value: 5 });
  host.send({ t: 'host_cmd', cmd: 'start' });
  ok(await students[0].wait(() => students[0].snaps.some(s => s.st === 'countdown')), 'بعد START تبدأ مرحلة العدّ التنازلي');
  ok(await students[0].wait(() => students[0].snaps.some(s => s.st === 'playing'), 8000), 'ثم تبدأ المباراة');

  // تزامن: لقطتان في نفس اللحظة تقريبًا عند طالبين على جهازين
  await sleep(1000);
  const a = students[0].snaps.at(-1), b = students[4].snaps.at(-1), h = host.snaps.at(-1);
  const near = Math.abs(a.b[0] - b.b[0]) < 6 && Math.abs(a.clk - b.clk) < 1;
  ok(near && Math.abs(a.clk - h.clk) < 1, `الكرة والساعة متزامنة بين الأجهزة (clk ${a.clk}/${b.clk}/${h.clk})`);
  ok(a.p.length === 22, 'اللقطة تحوي 22 لاعبًا (11 + 11)');
  ok(a.dur === 300, 'مدة المباراة 5 دقائق كما حدّدها المعلم');

  // تحريك اللاعبين: ادخال حركة وتحقق من تغير الموقع على لقطات الآخرين
  const pid0 = students[0].room.me.pid;
  const before = students[4].snaps.at(-1).p[pid0].slice(0, 2);
  students[0].send({ t: 'in', ax: 1, ay: 0.5, sp: 1 });
  const moveTimer = setInterval(() => students[0].send({ t: 'in', ax: 1, ay: 0.5, sp: 1 }), 100);
  await sleep(1500); clearInterval(moveTimer);
  const after = students[4].snaps.at(-1).p[pid0].slice(0, 2);
  ok(Math.hypot(after[0] - before[0], after[1] - before[1]) > 3, `حركة لاعب طالب تظهر عند طالب آخر (${before} → ${after})`);

  // إيقاف مؤقت: الساعة تتوقف
  host.send({ t: 'host_cmd', cmd: 'pause' }); await sleep(600);
  const c1 = host.snaps.at(-1).clk; await sleep(1200); const c2 = host.snaps.at(-1).clk;
  ok(host.snaps.at(-1).st === 'paused' && c1 === c2, 'الإيقاف المؤقت يجمّد الساعة (' + c1 + ' = ' + c2 + ')');
  host.send({ t: 'host_cmd', cmd: 'resume' }); await sleep(800);
  ok(host.snaps.at(-1).st !== 'paused', 'استكمال المباراة يعمل');

  // الأسئلة: ندفع الطلاب نحو المرمى مع الضغط على التسديد حتى يظهر سؤال
  let sawQuestion = null, correctQs = 0, goals = [0, 0], wrongAnswered = 0, sawShot = false;
  const t0 = Date.now();
  const drive = setInterval(() => {
    students.forEach((s, i) => {
      const snap = s.snaps.at(-1); if (!snap) return;
      const pid = s.room.me.pid, me = snap.p[pid], team = i < 3 ? 0 : 1, d = team === 0 ? 1 : -1;
      const bx = snap.b[0], by = snap.b[1];
      const owner = snap.b[3];
      let tx = bx, ty = by;
      if (owner === pid) { tx = d * 52; ty = 0; }
      const ax = tx - me[0], ay = ty - me[1], l = Math.hypot(ax, ay) || 1;
      s.send({ t: 'in', ax: ax / l, ay: ay / l, sp: 1 });
      if (owner === pid) s.send({ t: 'act', a: Math.random() < 0.3 ? 'shoot' : 'pass' });
      if (!owner || owner !== pid) if (Math.random() < 0.1) s.send({ t: 'act', a: 'tackle' });
      if (snap.q && snap.st === 'question' && snap.q.ans.includes(s.me.id) && !s.answeredQ !== snap.q.id) {
        if (s.lastQ !== snap.q.id) { s.lastQ = snap.q.id; sawQuestion = sawQuestion || snap.q;
          // اجعل كل ثالث إجابة خاطئة لاختبار المسارين
          const wrongNow = (snap.q.id % 3 === 0);
          const choice = wrongNow ? (snap.q.opts.length - 1) : 0; // لا نعرف الصحيحة؛ سنختار بالتجربة
          s.send({ t: 'answer', qid: snap.q.id, choice: +!wrongNow ? choiceGuess(snap.q) : choice });
        }
      }
    });
  }, 80);
  // المعلم لا يرى الإجابة الصحيحة؛ للاختبار نخمّن اعتمادًا على نص السؤال المعروف (الخادم لا يرسل الصحيحة)
  function choiceGuess(q) { return Math.floor(Math.random() * q.opts.length); }
  await host.wait(() => host.snaps.some(s => s.q), 90000);
  ok(host.snaps.some(s => s.q), 'ظهر سؤال علمي أثناء المباراة (ضمن اللعب)');
  const qs = host.snaps.filter(s => s.q).map(s => s.q);
  ok(qs.every(q => q.opts.length === 4 && q.correct === undefined && q.ok === undefined), 'السؤال يُرسل بأربعة اختيارات دون كشف الإجابة الصحيحة للعملاء');
  ok(qs.some(q => q.left <= 15 && q.total === 15), 'مؤقت الإجابة 15 ثانية');
  await host.wait(() => host.snaps.some(s => s.q && s.q.res), 30000);
  ok(host.snaps.some(s => s.q && s.q.res), 'نتيجة الإجابة تُعرض (صح/خطأ) للجميع');
  // مراقبة حتى يظهر هدف أو ننتظر 100 ثانية
  await host.wait(() => host.snaps.some(s => s.st === 'goal'), 120000);
  const goalSnap = host.snaps.find(s => s.st === 'goal');
  clearInterval(drive);
  console.log('   (اللعب استغرق', Math.round((Date.now() - t0) / 1000), 'ث؛ أهداف ظهرت؟', !!goalSnap, ')');
  if (goalSnap) ok(goalSnap.sc[0] + goalSnap.sc[1] >= 1 && goalSnap.goal && goalSnap.goal.scorer, 'تم تسجيل هدف بعد إجابة صحيحة + تسديدة + اجتياز خط المرمى — الهدّاف: ' + goalSnap.goal.scorer);
  else console.log('   ⚠ لم يُسجَّل هدف خلال الوقت المخصص للاختبار (الإجابات عشوائية)');

  // إنهاء
  host.send({ t: 'host_cmd', cmd: 'end' });
  ok(await host.wait(() => host.snaps.some(s => s.st === 'finished' && s.res), 4000), 'المعلم يُنهي المباراة وتظهر النتائج النهائية');
  const fin = host.snaps.find(s => s.st === 'finished' && s.res).res;
  ok(Array.isArray(fin.rows) && fin.rows.length === 6, 'جدول ترتيب الطلاب يحتوي 6 صفوف');
  ok(fin.mvp && fin.teams && fin.teams.length === 2, 'أفضل لاعب وملخص أداء الفريقين موجودان — MVP: ' + (fin.mvp && fin.mvp.name));
  console.log('   النتيجة:', fin.score.join(' - '), '| أكثر إجابات صحيحة:', fin.topAnswerer && fin.topAnswerer.name, '| الهداف:', fin.topScorer && fin.topScorer.name);

  // إعادة المباراة
  host.send({ t: 'host_cmd', cmd: 'restart' }); await sleep(600);
  const rs = host.snaps.at(-1);
  ok(rs.st === 'countdown' && rs.sc[0] === 0 && rs.sc[1] === 0 && rs.clk === 0, 'إعادة المباراة من البداية تُصفّر النتيجة والوقت');

  // إعادة اتصال طالب بنفس الهوية
  const tok = students[1].me.token; students[1].ws.close(); await sleep(300);
  const re = client('re'); await re.ready; re.send({ t: 'join', pin, token: tok });
  ok(await re.wait(() => re.me), 'إعادة اتصال طالب بالتوكن تعيد له نفس المقعد');
  ok(re.me.name === 'سارة' && re.me.team === 0, 'الاسم والفريق محفوظان بعد إعادة الاتصال');

  const failed = results.filter(r => !r[0]);
  console.log(`\n== النتيجة: ${results.length - failed.length}/${results.length} نجح`);
  [host, re, ...students].forEach(c => c.ws.close());
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
