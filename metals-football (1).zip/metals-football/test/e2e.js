'use strict';
const { chromium, devices } = require('playwright');
const URL = process.argv[2] || 'http://localhost:3111';
const OUT = __dirname + '/shots/';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const errs = [];
(async () => {
  const br = await chromium.launch({ args: ['--use-gl=swiftshader', '--autoplay-policy=no-user-gesture-required'] });
  const mk = async (name, opts) => { const ctx = await br.newContext(opts); const p = await ctx.newPage(); p.on('pageerror', e => errs.push(name + ' PAGEERROR ' + e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(name + ' console: ' + m.text()); }); return p; };
  const host = await mk('host', { viewport: { width: 1360, height: 820 } });
  const s1 = await mk('s1', { viewport: { width: 1280, height: 720 } });
  const s2 = await mk('s2', { ...devices['iPhone 13 landscape'] });
  await host.goto(URL + '/host'); await host.click('#btnCreate'); await host.waitForFunction(() => document.getElementById('hPin').textContent.match(/\d{6}/));
  const pin = await host.textContent('#hPin'); console.log('PIN', pin);
  await host.screenshot({ path: OUT + '01-host-lobby.png' });

  await s1.goto(URL + '/?pin=' + pin); await s1.screenshot({ path: OUT + '02-join.png' });
  await s1.fill('#inName', 'أحمد'); await s1.click('#btnJoin');
  await s1.waitForSelector('#s-intro:not(.hidden)'); await sleep(300);
  await s1.screenshot({ path: OUT + '03-intro-table.png' });
  await s1.mouse.click(500, 250);                                  // تسديد الكرة نحو الجدول
  await s1.waitForSelector('#elModal:not(.hidden)', { timeout: 8000 });
  await sleep(300); await s1.screenshot({ path: OUT + '04-element-card.png' });
  await s1.click('#btnElNext'); await s1.waitForSelector('#s-team:not(.hidden)');
  await s1.screenshot({ path: OUT + '05-team.png' });
  await s1.click('#tb0'); await s1.waitForSelector('#s-lobby:not(.hidden)'); await sleep(300);
  await s1.screenshot({ path: OUT + '06-lobby.png' });

  await s2.goto(URL + '/?pin=' + pin); await s2.fill('#inName', 'سارة'); await s2.click('#btnJoin');
  await s2.waitForSelector('#s-intro:not(.hidden)'); await sleep(300);
  await s2.screenshot({ path: OUT + '07-mobile-intro.png' });
  const box = await s2.locator('#ptable').boundingBox(); await s2.touchscreen.tap(box.x + box.width / 2, box.y + 80);
  await s2.waitForSelector('#elModal:not(.hidden)', { timeout: 8000 }); await s2.click('#btnElNext');
  await s2.waitForSelector('#s-team:not(.hidden)'); await s2.click('#tb1'); await s2.waitForSelector('#s-lobby:not(.hidden)');
  await sleep(500);
  console.log('host sees students:', await host.textContent('#hCount'), '| counts', await host.textContent('#hc0'), await host.textContent('#hc1'));
  await host.screenshot({ path: OUT + '08-host-with-students.png' });

  await host.selectOption('#selDur', '5'); await host.click('#btnStart');
  await s1.waitForSelector('#game:not(.hidden)', { timeout: 8000 }); await s2.waitForSelector('#game:not(.hidden)', { timeout: 8000 });
  await sleep(1000); await s1.screenshot({ path: OUT + '09-countdown.png' });
  await s1.waitForFunction(() => document.getElementById('half').textContent === 'LIVE' && !document.querySelector('#cdown'), null, { timeout: 10000 });
  // حركة بالكيبورد
  await s1.keyboard.down('KeyD'); await s1.keyboard.down('Shift'); await sleep(2500);
  await s1.screenshot({ path: OUT + '10-gameplay-desktop.png' });
  await s1.keyboard.up('KeyD'); await s1.keyboard.up('Shift');
  await s2.screenshot({ path: OUT + '11-gameplay-mobile.png' });
  await host.screenshot({ path: OUT + '12-host-live.png' });
  // صافرة/إيقاف
  await host.click('#btnPause'); await sleep(1500);
  console.log('paused overlay on student:', !(await s1.locator('#status-ov').evaluate(e => e.classList.contains('hidden'))));
  await s1.screenshot({ path: OUT + '13-paused.png' });
  await host.click('#btnResume'); await sleep(500);

  // دفع اللاعب نحو المرمى مع التسديد لإظهار سؤال
  let gotQ = false; const t0 = Date.now();
  const drive = (async () => {
    while (Date.now() - t0 < 120000 && !gotQ) {
      const st = await s1.evaluate(() => { const v = window.__v; return null; });
      await s1.keyboard.down('KeyD'); await s1.keyboard.down('Shift'); await s1.keyboard.press('KeyJ'); await sleep(150);
      gotQ = await s1.locator('#qpanel:not(.hidden)').count() > 0;
    }
  })();
  await drive; await s1.keyboard.up('KeyD'); await s1.keyboard.up('Shift');
  console.log('question appeared for student:', gotQ, 'after', Math.round((Date.now() - t0) / 1000) + 's');
  if (gotQ) {
    await sleep(500); await s1.screenshot({ path: OUT + '14-question.png' }); await host.screenshot({ path: OUT + '15-host-question.png' });
    await s1.keyboard.press('Digit1'); await sleep(900); await s1.screenshot({ path: OUT + '16-answered.png' });
    await sleep(5000); await s1.screenshot({ path: OUT + '17-after-answer.png' });
  }
  await host.click('#btnEnd', { noWaitAfter: true }).catch(() => { });
  host.once('dialog', d => d.accept());
  await sleep(300);
  await host.evaluate(() => { window.confirm = () => true; }); await host.click('#btnEnd'); await sleep(1500);
  await s1.waitForSelector('#s-end:not(.hidden)', { timeout: 6000 }); await sleep(400);
  await s1.screenshot({ path: OUT + '18-end-student.png', fullPage: false });
  await host.screenshot({ path: OUT + '19-end-host.png', fullPage: true });
  console.log('\nconsole/page errors:', errs.length); errs.forEach(e => console.log(' -', e));
  await br.close();
})().catch(e => { console.error('E2E FAIL', e); process.exit(1); });
